# COUNTER STRIKE: ULTIMATE WARFARE

Proyecto Godot 4.3. Incluye una configuración preliminar de exportación Android y un workflow de GitHub Actions para compilar un APK de depuración en la nube.

Consulta `BUILD_FROM_ANDROID_TABLET.md` para subir el proyecto desde una tablet Android y descargar el APK compilado.

Estado: fuente de desarrollo; no se garantiza que la primera compilación sea correcta ni que todos los sistemas estén integrados o probados. El APK solo existe después de que GitHub Actions termine correctamente y publique el artefacto.
