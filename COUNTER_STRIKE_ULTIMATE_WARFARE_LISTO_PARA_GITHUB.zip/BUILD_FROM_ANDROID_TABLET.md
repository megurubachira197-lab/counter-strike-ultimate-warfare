# Obtener el APK desde una tablet Android

Este proyecto incluye un flujo de compilación en GitHub Actions. GitHub compila el APK en sus servidores; la tablet solo necesita un navegador.

## Pasos
1. En Chrome, entra en https://github.com y crea una cuenta o inicia sesión.
2. Crea un repositorio nuevo (por ejemplo `counter-strike-ultimate-warfare`). Puede ser privado. No marques la opción de crear README, licencia ni `.gitignore`.
3. En el repositorio, usa **Add file → Upload files** y sube el contenido de este ZIP (no el ZIP como un único archivo). Asegúrate de que `project.godot` quede en la raíz del repositorio y que también se suba la carpeta oculta `.github/workflows`.
4. Pulsa **Commit changes**.
5. Abre la pestaña **Actions**, selecciona **Build Android APK** y pulsa **Run workflow** si no se ha iniciado automáticamente.
6. Espera a que el trabajo termine en verde. Abre la ejecución y descarga el artefacto `CounterStrike-Ultimate-Warfare-APK`.
7. Descomprime el artefacto y abre el APK. Android puede pedir permiso para instalar aplicaciones desde Chrome/Archivos.

## Importante
- Este flujo genera un APK de depuración para pruebas, no una publicación firmada para Google Play.
- La compilación puede detectar errores del proyecto o incompatibilidades. Si falla, abre el trabajo y comparte el texto del error para corregirlo.
- El proyecto todavía no ha sido probado en ejecución en este entorno. Este flujo no convierte automáticamente los catálogos de armas/mapas/skins en contenido 3D terminado.
